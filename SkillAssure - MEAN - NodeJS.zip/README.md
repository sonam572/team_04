# Express Quickstart

## How to run

- Clone/download this repo
- Change `config/config.config.env` to `config/config.env`
- Add your JWT secret and MongoDB URI
- run `npm run dev` on the console from the project root directory
